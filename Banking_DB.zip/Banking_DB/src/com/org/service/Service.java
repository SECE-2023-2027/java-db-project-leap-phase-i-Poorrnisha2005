package com.org.service;

public interface Service {
	void createaccount();
	void viewaccount();
	void updateaccount();
	void withdraw();
	void deposit();
	void amount_trans();
	void viewtrans();

}
